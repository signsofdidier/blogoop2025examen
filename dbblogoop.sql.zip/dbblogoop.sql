-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 03 feb 2025 om 11:24
-- Serverversie: 8.3.0
-- PHP-versie: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbblogoop`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `author_id` int NOT NULL,
  `photo_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `blogs`
--

INSERT INTO `blogs` (`id`, `author_id`, `photo_id`, `title`, `description`, `created_at`, `deleted_at`) VALUES
(1, 1, 7, 'Blog1', 'test 1', '2025-01-29 08:38:40', '0000-00-00 00:00:00'),
(2, 1, 6, 'tt', 'tt', '2025-01-29 08:40:31', '0000-00-00 00:00:00'),
(3, 1, 3, 'dd', 'dd', '2025-01-29 08:44:25', '2025-01-30 13:52:46'),
(4, 1, 4, 'tt', 'tt', '2025-01-29 08:46:10', '0000-00-00 00:00:00'),
(5, 1, 5, 'test', 'test', '2025-01-30 13:37:55', '0000-00-00 00:00:00'),
(6, 1, 0, 'test', 'test', '2025-01-30 13:44:44', '0000-00-00 00:00:00'),
(7, 1, 12, 'dd', 'dd', '2025-02-01 10:11:22', '0000-00-00 00:00:00'),
(8, 1, 11, 'd', 'd', '2025-02-01 10:12:41', '0000-00-00 00:00:00'),
(9, 1, 10, 'dd', 'dd', '2025-02-01 11:02:04', '0000-00-00 00:00:00'),
(10, 1, 13, 'dd', 'dd', '2025-02-01 11:13:09', '0000-00-00 00:00:00'),
(11, 1, 0, 'test', 'NULL', '2025-02-01 12:05:50', '0000-00-00 00:00:00'),
(12, 1, 0, 'testddssd', 'NULL', '2025-02-01 12:09:31', '0000-00-00 00:00:00'),
(13, 1, 19, 'dd', 'dsfds', '2025-02-01 12:11:03', '0000-00-00 00:00:00'),
(14, 1, 0, 'dd', 'NULL', '2025-02-01 12:11:59', '0000-00-00 00:00:00'),
(15, 1, 14, 'dd', 'dd', '2025-02-01 12:17:46', '0000-00-00 00:00:00'),
(16, 1, 15, 'ddsf', 'dsdfs', '2025-02-01 12:32:58', '0000-00-00 00:00:00'),
(17, 1, 16, 'dd', 'dd', '2025-02-01 12:33:52', '0000-00-00 00:00:00'),
(18, 1, 17, 'dd', 'dd', '2025-02-01 12:35:01', '2025-02-02 09:24:01'),
(19, 1, 18, 'dsdsf', 'sdffd', '2025-02-01 12:37:12', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `blogs_categories`
--

DROP TABLE IF EXISTS `blogs_categories`;
CREATE TABLE IF NOT EXISTS `blogs_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blog_id` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `blogs_categories`
--

INSERT INTO `blogs_categories` (`id`, `blog_id`, `category_id`) VALUES
(1, NULL, 2),
(2, NULL, 1),
(6, 13, 2),
(5, 19, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `deleted_at`) VALUES
(1, 'sport', '2025-02-01 11:58:51', '0000-00-00 00:00:00'),
(2, 'news', '2025-02-01 12:11:59', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int NOT NULL,
  `alternate_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'https://www.syntrawest.be',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `photos`
--

INSERT INTO `photos` (`id`, `title`, `description`, `filename`, `type`, `size`, `alternate_text`, `created_at`, `deleted_at`) VALUES
(1, 'Blog1', 'test 1', 'adidas2025_01_30_14_38_46.webp', 'image/webp', 3620, 'anonymous', '2025-01-30 13:34:31', '0000-00-00 00:00:00'),
(2, 'tt', 'tt', 'anonymous-mask-hackers-2-1024x5852025_01_30_14_42_29.webp', 'image/webp', 24002, 'color', '2025-01-30 13:34:45', '0000-00-00 00:00:00'),
(3, 'johan', 'johan', 'johandeneve2025_01_30_14_34_56.png', 'image/png', 691189, 'johan', '2025-01-30 13:34:56', '0000-00-00 00:00:00'),
(4, 'logo', 'log', 'logo2025_01_30_14_35_07.png', 'image/png', 215518, 'log', '2025-01-30 13:35:07', '0000-00-00 00:00:00'),
(5, 'test', 'test', 'adidas2025_01_30_14_41_35.webp', 'image/webp', 3620, 'NULL', '2025-01-30 13:41:35', '0000-00-00 00:00:00'),
(6, 'tt', 'tt', 'adidas2025_01_30_14_42_44.webp', 'image/webp', 3620, 'NULL', '2025-01-30 13:42:44', '0000-00-00 00:00:00'),
(7, 'Blog1', 'test 1', 'kledij2025_01_30_14_44_14.jpg', 'image/jpeg', 85262, 'NULL', '2025-01-30 13:44:14', '0000-00-00 00:00:00'),
(8, 'test', 'test', 'eyVeRQ83SyCqLhzEvVKJvw2025_01_30_14_52_15.webp', 'image/webp', 1074726, 'NULL', '2025-01-30 13:44:44', '0000-00-00 00:00:00'),
(9, 'test', 'test', '10000179162025_02_01_12_01_45.jpg', 'image/jpeg', 434595, 'NULL', '2025-01-30 13:52:24', '0000-00-00 00:00:00'),
(10, 'dd', 'dd', '10000179162025_02_01_12_02_04.jpg', 'image/jpeg', 434595, 'NULL', '2025-02-01 11:02:04', '0000-00-00 00:00:00'),
(11, 'd', 'd', '10000179542025_02_01_12_02_21.jpg', 'image/jpeg', 574624, 'NULL', '2025-02-01 11:02:21', '0000-00-00 00:00:00'),
(12, 'dd', 'dd', '10000219182025_02_01_12_12_52.jpg', 'image/jpeg', 1172301, 'NULL', '2025-02-01 11:12:52', '0000-00-00 00:00:00'),
(13, 'dd', 'dd', '10000222212025_02_01_12_13_09.jpg', 'image/jpeg', 478077, 'NULL', '2025-02-01 11:13:09', '0000-00-00 00:00:00'),
(14, 'dd', 'dd', '10000179162025_02_01_13_17_46.jpg', 'image/jpeg', 434595, 'NULL', '2025-02-01 12:17:46', '0000-00-00 00:00:00'),
(15, 'ddsf', 'dsdfs', '10000321332025_02_01_13_32_58.jpg', 'image/jpeg', 527858, 'NULL', '2025-02-01 12:32:58', '0000-00-00 00:00:00'),
(16, 'dd', 'dd', '10000221482025_02_01_13_33_52.jpg', 'image/jpeg', 514212, 'NULL', '2025-02-01 12:33:52', '0000-00-00 00:00:00'),
(17, 'dd', 'dd', '1000022224(1)2025_02_01_13_35_01.jpg', 'image/jpeg', 546877, 'NULL', '2025-02-01 12:35:01', '0000-00-00 00:00:00'),
(18, 'dsdsf', 'sdffd', '10000350472025_02_01_13_37_12.jpg', 'image/jpeg', 402049, 'NULL', '2025-02-01 12:37:12', '0000-00-00 00:00:00'),
(19, 'dd', 'dsfds', '10000222212025_02_02_10_23_46.jpg', 'image/jpeg', 478077, 'NULL', '2025-02-02 09:23:46', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'admin'),
(2, 'user');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NOT NULL,
  `role_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `created_at`, `deleted_at`, `role_id`) VALUES
(1, 'Tom', '12345678', 'Tom', 'Vanhoutte', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 1),
(2, 'Tim', '12345678', 'Tim', 'Vanhoutte', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 1),
(3, 'test', 'test', 'test', 'WILLIAMS', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(4, 'test', 'test', 'Ike', 'WILLIAMS', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(6, 'ttt', 'test', 'test', 'test', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(7, 'test', 'test', 'test', 'test', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(8, 'test', 'test', 'test', 'test', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(9, 'test', 'test', 'test', 'test', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(10, 'test', 'test', 'test', 'test', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(11, 'tester', '12345678', 'tester', 'tester', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(12, 'ttt', 'ttt', 'ttt', 'ttt', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(13, 'dsdsfds', 'ddssd', 'dsdsf', 'dsds', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(14, 'ddd', 'ddd', 'ddd', 'ddd', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(15, 'ddd', 'ddd', 'ddd', 'ddd', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(16, 'dsdds', 'dsdsds', 'dsds', 'dsdds', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(17, 'dsds', 'sdsd', 'dsdd', 'dsds', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(18, 'esdsdf', 'sddsffsd', 'sdffds', 'sddsffsd', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(19, 'dsffds', 'dsfdsf', 'dsdfs', 'dsdsf', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(20, 'dsffds', 'dsfdsf', 'dsdfs', 'dsdsf', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(21, 'dfsdf', 'fdsfsd', 'dfdfsds', 'dsfdsf', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(22, 'dfsdf', 'fdsfsd', 'dfdfsds', 'dsfdsf', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(23, 'dsffds', 'dsfdsf', 'dsdfs', 'dsdsf', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(24, 'cxvcvx', 'cxcvx', 'cxcxv', 'cxcvx', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(25, 'dsdsfdsf', 'dsffdsdf', 'dsfdsfsdf', 'dsfdsdfs', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(26, 'ddsf', 'dfsdf', 'dsfdsf', 'dsdsfsdf', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(27, 'dsfdsf', 'sddfssdf', 'dsdsf', 'dsdsf', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(28, 'aaa', 'aaa', 'aaa', 'aaa', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(29, 'test1', 'test1', 'test1', 'test1', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(30, 'test2', 'test2', 'test2', 'test2', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(31, 'test3', 'test3', 'test3d', 'test3', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(32, 'test4', 'test4', 'test4', 'test4', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(33, '', '', '', '', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(34, 'test5', 'test5', 'test5', 'test5', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(36, 'test10', 'test10', 'test10', 'test10', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(38, 'test20', 'test20', 'test20', 'test20', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(41, 'test234', 'test234', 'test234', 'test234', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(43, 'ttt', '', '', '', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(44, 'ttt', '', '', '', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(45, 'ttt', '', '', '', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(46, 'ttt', 'NULL', 'NULL', 'NULL', '2025-01-27 11:39:33', '2025-01-27 11:20:07', 2),
(47, 'tttddd', 'NULL', 'ddd', 'ddd', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(48, 'tttddd', 'NULL', 'ddd', 'ddd', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(51, 'tttddd', 'NULL', 'ddddd', 'dddddd', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(53, 'dsfdfs', 'dsdsfsdf', 'dsdsfsdf', 'sddsf', '2025-01-27 11:39:33', '2025-01-27 10:41:18', 2),
(54, 'testje', 'dsdsfds', 'dsfdsdf', 'dsdsfds', '2025-01-27 11:39:33', '0000-00-00 00:00:00', 2),
(55, 'test', '123', 'test', 'test', '0000-00-00 00:00:00', '2025-01-27 11:35:16', 2),
(56, 'ddd', 'ddd', 'ddd', 'ddd', '2025-01-27 11:33:33', '2025-02-03 10:12:55', 2),
(57, 'dddddd', 'ddddd', 'ddddddd', 'ddddd', '2025-01-27 11:51:13', '0000-00-00 00:00:00', 2),
(67, 'admin_user', '12345678', 'admin_user', 'admin_user', '2025-02-03 09:05:31', '0000-00-00 00:00:00', 1),
(68, 'gjinadmin', '123456', 'Gene', 'Admin', '2025-02-03 09:51:32', '0000-00-00 00:00:00', 2),
(71, 'jan', '123', 'jan', 'jan', '2025-02-03 09:58:16', '2025-02-03 09:59:31', 2);

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
